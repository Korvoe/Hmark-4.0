public class Array3  {
    public static void main(String[] args) {
	Integer b[] = {4, 5, 6, 12};
    int x = 0;
int y = 1;

        System.out.println(b[y+x+x+1+x+y].toString());
        System.out.println(b[1].toString());
        System.out.println(b[2].toString());
    }
}
