class Switch2 {
    public static void main(String[] args) {
	int x = 1;
	int y = 0;
	switch (x) {
	default:
	    y = 4;
	    break;
	}
	System.out.println(y);
    }
}
