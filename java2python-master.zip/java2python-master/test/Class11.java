class Class11 {
    Integer x = 0;

    String any() {
	return x.toString();
    }

    public static void main(String[] args) {
	Class11 c = new Class11();
        System.out.println( c.any() );
    }


}
