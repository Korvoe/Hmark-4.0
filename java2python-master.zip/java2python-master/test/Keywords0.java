public class Keywords0 {
    public static void main(String[] args) {

	String and = "this is and";
	System.out.println(and == "this is and" ? 1 : 0);

	String del = "this is del";
	System.out.println(del == "this is del" ? 1 : 0);

	String elif = "this is elif";
	System.out.println(elif == "this is elif" ? 1 : 0);

	String from = "this is from";
	System.out.println(from == "this is from" ? 1 : 0);

	String in = "this is in";
	System.out.println(in == "this is in" ? 1 : 0);

	String is = "this is is";
	System.out.println(is == "this is is" ? 1 : 0);

	String not = "this is not";
	System.out.println(not == "this is not" ? 1 : 0);

	String or = "this is or";
	System.out.println(or == "this is or" ? 1 : 0);

	String print = "this is print";
	System.out.println(print == "this is print" ? 1 : 0);

	String str = "this is str";
	System.out.println(str == "this is str" ? 1 : 0);

	String None = "this is None";
	System.out.println(None == "this is None" ? 1 : 0);

	String bool = "this is bool";
	System.out.println(bool == "this is bool" ? 1 : 0);

	String True = "this is True";
	System.out.println(True == "this is True" ? 1 : 0);

	String False = "this is False";
	System.out.println(False == "this is False" ? 1 : 0);

    }


}
