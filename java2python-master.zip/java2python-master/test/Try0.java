class Try0 {

    public static void main(String[] args) {
        try {
            System.out.println(0);
        } catch (Exception e) {
        }


        try {
            System.out.println(1);
        } catch (Exception e) {
            System.out.println(2);
        }

    }
}
