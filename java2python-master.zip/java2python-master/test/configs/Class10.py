modulePrologueHandlers = [
        'from java2python.mod.include.overloading import overloaded',
    ]
