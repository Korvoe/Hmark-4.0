from java2python.mod import basic

moduleImportDeclarationHandler = basic.simpleImports
