from java2python.mod import basic

expressionCastHandler = basic.castDrop
