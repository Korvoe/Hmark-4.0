#!/usr/bin/env python
""" generated source for module Class0

"""
# package: Package0
class Class0(object):
    """ generated source for class Class0

    """
    def m(self):
        """ generated source for method m

        """
        return 42

