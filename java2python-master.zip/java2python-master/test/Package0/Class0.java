package Package0;

public class Class0 {
    public int m() {
	return 42;
    }
}
