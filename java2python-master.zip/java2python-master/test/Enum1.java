enum Day  {
    SUNDAY, MONDAY, TUESDAY, WEDNESDAY, THURSDAY, FRIDAY, SATURDAY;
}

class Enum1 {
    public static void main(String[] args) {
        System.out.println(Day.SUNDAY);
    }
}
