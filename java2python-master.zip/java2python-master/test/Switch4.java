class Switch4 {
    public static void main(String[] args) {
	int x = 1;
	switch (x) {
           // empty switch
	}
	System.out.println(x);
    }
}
