class BasicTypes1 {
    char chr;
    byte byt;
    short shr;
    int in_t;
    long lng;
    float flt;
    double dbl;

    public static void main(String[] args) {
        BasicTypes1 bt1 = new BasicTypes1();
        System.out.println(bt1.byt);
        System.out.println(bt1.shr);
        System.out.println(bt1.in_t);
    }

}
