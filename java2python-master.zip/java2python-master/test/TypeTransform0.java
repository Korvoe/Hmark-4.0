class TypeTransform0 {
    public boolean b;
    public double d;

    public static void main(String[] args) {}
}