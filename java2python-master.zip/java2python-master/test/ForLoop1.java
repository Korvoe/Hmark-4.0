class ForLoop1 {
    public static void main(String[] args) {
        int x = 0;
        for (;;) {
            if (x==2) { break; }
	    System.out.println(x);
            x += 1;
        }
    }
}
