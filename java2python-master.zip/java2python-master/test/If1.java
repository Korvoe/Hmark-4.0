class If1 {
    public static void main(String[] args) {
	int x = 0;
	if (x == 0) {
	    System.out.println(1);
	}

	if (x == 1) {
	    System.out.println(1);
	    System.out.println(2);
	} else {
	    System.out.println(0);
	}
    }
}
