class Switch1 {
    public static void main(String[] args) {
	int x = 1;
	switch (x) {
            case 0:
	}
	System.out.println(x);
    }
}
