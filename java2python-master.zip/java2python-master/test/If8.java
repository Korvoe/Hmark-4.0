class If8 {
    public static void main(String[] args) {
        if (true) {
            int y = 1;
            System.out.println(0 + y);
        }
    }
}
