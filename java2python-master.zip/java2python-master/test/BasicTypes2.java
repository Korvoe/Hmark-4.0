class BasicTypes2 {
    public static void main(String[] args) {

        Integer I = 32;
        System.out.println(I);

        Boolean B = true;
        System.out.println( B ? "ok" : "nope" );

        Byte Y = 0;
        System.out.println(Y);

        Character C = 'c';
        System.out.println(C);

        Short S = 128;
        System.out.println(S);

        Long L = 128L;
        System.out.println(L);

        Float F = 1.5F;
        System.out.println(F);

        Double D = 1.5;
        System.out.println(D);

        String T = "done";
        System.out.println(T);


    }
}
