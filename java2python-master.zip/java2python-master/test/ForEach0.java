class ForEach0 {
    public static void main(String[] args) {
        int ints[] = {1, 2, 3, 4};
        for (int i: ints) {
	    System.out.println(i);
        }
    }
}
