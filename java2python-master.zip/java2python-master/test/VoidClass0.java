
class VoidClass0 {

    public static void main(String[] args) {
        Class x = void.class;
    }
}
