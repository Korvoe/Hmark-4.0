class If7 {
    public static void main(String[] args) {
        if (false) {
            System.out.println("fail 1");
        } else if (false) {
            System.out.println("fail 2");
        } else {
        }
    }
}