class BasicTypes0 {
    public static void main(String[] args) {

        byte B = 127;
        System.out.println(B);

        short S = 10240;
        System.out.println(S);

        char C = 'x';
        System.out.println(C);

        int I = 48;
        System.out.println(I);


        long L = 1234567890;
        System.out.println(L);

        float F = 0.1f;
        System.out.println(F);

        double D = 0.1;
        System.out.println(D);

        boolean O = true;
        System.out.println(O ? 42 : -3);

    }
}
