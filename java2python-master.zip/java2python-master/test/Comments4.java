// Header Comment

class Comments4 {
  void method() {
      for (;;) {  }
  }

    public static void main(String[] args) {
        System.out.println("Comments4.");
    }

}
