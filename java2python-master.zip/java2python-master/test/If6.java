class If6 {
    public static void main(String[] args) {
        if (false) {
            System.out.println("fail");
        } else if (true) {
            System.out.println("okay");
        }
    }

}
