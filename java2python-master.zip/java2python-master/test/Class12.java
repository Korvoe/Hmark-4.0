class Class12 {
    private int c = 12;

    private void x() {
	System.out.println('x');
    }

    public static void main(String[] args) {
	Class12 c = new Class12();
	c.x();
    }
}
