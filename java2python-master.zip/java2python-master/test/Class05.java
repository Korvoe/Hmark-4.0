// tests basic subclassing
class Base {
}


class Class05 extends Base {
    public static void main(String[] args) {
        System.out.println("extends");
    }
}