/* leading ml comment */
class /* sneaky 0 */ Class00 { // block line comment
    public static void main(String[] args) {}
}
