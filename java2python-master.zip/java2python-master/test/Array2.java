public class Array2  {
    public static void main(String[] args) {
	Integer b[] = {4, 5, 6};
        System.out.println(b[0].toString());
        System.out.println(b[1].toString());
        System.out.println(b[2].toString());

	int c[] = {1,2,3};
        System.out.println(c[0]);
        System.out.println(c[1]);
        System.out.println(c[2]);

	String d[] = {"a", "s", "d", "f"};
        System.out.println(d[0]);
        System.out.println(d[1]);
        System.out.println(d[2]);
        System.out.println(d[3]);

	String[] e;
	e = new String[2];
	e[0] = "4";
	e[1] = "2";
        System.out.println(e[0]);
        System.out.println(e[1]);

    }
}
