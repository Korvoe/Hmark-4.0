class Math0 {
    public static void main(String[] args) {
        System.out.println(Math.abs(-42));
        System.out.println(Math.abs(-0.5));
    }
}
