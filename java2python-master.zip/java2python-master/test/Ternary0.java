final class Ternary0 extends Object {
    public static void main(String[] args) {
        System.out.println(1 > 0 ? 'a' : 'b');
        System.out.println(1 == 0 ? 'a' : 'b');
    }
}
