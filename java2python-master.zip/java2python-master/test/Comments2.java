/**

multiline comment above the Comments class.

**/



class Comments2 {
    // single line comment below the Comments class.
    int x = 1;

    /** multi above other method **/
    public static void other() {
    // single inside other method
    }

    public static void main(String[] args) {
    }


}
