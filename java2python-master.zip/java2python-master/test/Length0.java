class Length0 {
    public static int dummy(int v) {
        return v + 1;
    }

    public static void main(String[] args) {
        String foo = "asdf";
        System.out.println( dummy(foo.length() ) );
    }

}