class String0 {
    static void test(String s) {
        System.out.println(s);
    }

    public static void main(String[] args) {
        test(String.valueOf(42));
    }
}
