class If2 {
    public static void main(String[] args) {
	int x = 0;

	if (x == 0)
	    System.out.println(0);
    }
}
