class ForLoop0 {
    public static void main(String[] args) {
        int ints[] = {1, 2, 3, 4};
        for (int i = 0; i < 3; i++) {
	    System.out.println(i);
        }
    }
}
