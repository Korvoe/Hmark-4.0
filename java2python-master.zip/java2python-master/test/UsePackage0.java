import Package0.*;

class UsePackage0 {
    public static void main(String[] args) {
	Package0.Class0 c = new Package0.Class0();
        System.out.println( c.m() );
    }
}
