class Array0 {
    static int a[] = {1, 2, 3};

    public static void main(String[] args) {

    }
}
