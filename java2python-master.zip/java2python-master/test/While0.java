class While0 {
    public static void main(String[] args) {
	int x = 10;
	while (x>10) {
	}
        System.out.println("ok");
    }
}
