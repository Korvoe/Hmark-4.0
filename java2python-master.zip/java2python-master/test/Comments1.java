/**

multiline comment above the Comments class.

**/

// single line comment above the Comments class.

class Comments1 {
    /** multi above other method **/
    // single above other method
    public static void other() { int j = 1;}

    /** multi above main method **/
    // single above main method
    public static void main(String[] args) {
	/** multi inside the main method

	 **/
	// single line comment inside the main method
        int /** expr 1 **/ i = /** expr 2 **/ 1 /** expr 3 **/; /** expr 4 **/ // expr 5
// skeaky 1
    } // skeaky 2
// skeaky 3
} // skeaky 4
// skeaky 5
