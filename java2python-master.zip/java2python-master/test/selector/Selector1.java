class Selector1 {
    void bar(int x, int y) {
        int foo = 3;
	String z = "foo";
    }

    void foo() {};

}