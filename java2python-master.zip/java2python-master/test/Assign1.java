class Assign1 {
    public static void main(String[] args) {
        int x = 42;
        System.out.println(x);

        x >>>= 1;
        System.out.println(x);
        x >>>= 3;
    }
}
