class If4 {
    public static void main(String[] args) {
	int x = 0;

	if (x == 1)
	    System.out.println(1);
        else if (x == 2)
	    System.out.println(2);
        else if (x == 3)
	    System.out.println(3);
        else
	    System.out.println(0);
    }
}
