class DoWhile0 {
    public static void main(String[] args) {
	int x = 10;
	do {
	    System.out.println(x);
	    x++;
	} while (x<10);
    }
}
