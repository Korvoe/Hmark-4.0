@interface Example {}

@Example
public class Anno0 {
    public static void main(String[] args) {
        System.out.println(0);
    }
}