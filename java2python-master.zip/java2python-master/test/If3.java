class If3 {
    public static void main(String[] args) {
	int x = 0;

	if (x == 1)
	    System.out.println(0);
        else
	    System.out.println(1);
    }
}
