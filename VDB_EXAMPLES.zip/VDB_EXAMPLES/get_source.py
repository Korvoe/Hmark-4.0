import os
import sys
import shutil
import re
import glob
import json
import multiprocessing as mp
from functools import partial
import platform
import time

#from src.DB import query
from src.vulgen import parseutility2 as parseutility
#from src.utils.getConfig import getConfig

#config = getConfig()

 #GLOBALS
#originalDir = config.workingDir
#diffDir     = config.diffDir
originalDir = "/home/ibragim/Dev/Hmark/Hmark-ctags/VDB_EXAMPLES/"
diffDir = "/home/ibragim/Dev/Hmark/Hmark-ctags/VDB_EXAMPLES/data/diff"

# resultList = []
dummyFunction = parseutility.function(None)
multimodeFlag = 0
debugMode = True

parseutility.setEnvironment("")

t1 = time.time()

""" re patterns """
pat_src = '[\n](?=diff --git a/)'
pat_chunk = '[\n](?=@@\s[^a-zA-Z]*\s[^a-zA-Z]*\s@@)'
pat_linenum = r"-(\d+,\d+) \+(\d+,\d+) "
pat_linenum = re.compile(pat_linenum)

def init():
        # try making missing directories
        try:
            os.makedirs(os.path.join(originalDir, 'tmp'))
        except OSError as e:
            pass
        try:
            os.makedirs(os.path.join(originalDir, 'vul'))
        except OSError as e:
            pass

def source_from_cvepatch(ctr, diffFileName):  # diffFileName holds the filename of each DIFF patch
    # diffFileName looks like: CVE-2012-2372_7a9bc620049fed37a798f478c5699a11726b3d33.diff
    global repoName
    global debugMode
    global total
    global multimodeFlag
    global dummyFunction
    global diffDir
    global originalDir
    global language

    chunksCnt = 0   # number of DIFF patches
    currentCounter = 0  # not used in this format ( we do not need to seperate files with number. we had done it with index hash of each file)

    with ctr.diffFileCntLock:
        currentCounter = ctr.diffFileCnt.value
        print(str(ctr.diffFileCnt.value + 1) + '/' + str(total))
        ctr.diffFileCnt.value += 1

    if os.path.getsize(os.path.join(diffDir, repoName, diffFileName)) > 1000000:
        # don't do anything with big DIFFs (merges, upgrades, ...)
        print("[-]", diffFileName, "\t(file too large)")
    else:
        '''
        # new format does not need split information
        diffFileNameSplitted = diffFileName.split('_')
        cveId = diffFileNameSplitted[0]
        commitHashValue = diffFileNameSplitted[-1].splitted('.')[0]
        '''

        print("[+]", diffFileName, "\t(proceed)")
        with open(os.path.join(diffDir, repoName, diffFileName), 'r', encoding='UTF8') as fp:
            patchLines = ''.join(fp.readlines())
            patchLinesSplitted = re.split(pat_src, patchLines);
            commitLog = patchLinesSplitted[0]       # git case => we have to consider svn case here
            affectedFilesList = patchLinesSplitted[1:]
#            print(affectedFilesList)

        repoPath = ''
        if multimodeFlag:   # multimode DIFFs have repoPath at the beginning.
            repoPath = commitLog.split('\n')[0].rstrip().lstrip("\xef\xbb\xbf")

        numAffectedFiles = len(affectedFilesList)
        for aidx, affectedFile in enumerate(affectedFilesList):
            if debugMode:
                print("\tFile # " + str(aidx + 1) + '/' + str(numAffectedFiles)),
            firstLine = affectedFile.split('\n')[0] # diff --git a/path/filename.ext b/path/filename.ext
            affectedFileName = firstLine.split("--git ")[1].split(" ")[0].split("/")[-1]
            codePath = firstLine.split(' b')[1].strip() # path/filename.ext
            if not codePath.endswith(".c") and not codePath.endswith(".cpp") and not codePath.endswith(".cc") and not codePath.endswith(".c++") and not codePath.endswith(".cxx") and not codePath.endswith(".go") and not codePath.endswith(".java") and not codePath.endswith(".py") and not codePath.endswith(".js"):
                if debugMode:
                    print("\t[-]", codePath, "(wrong extension)")
            else:
                secondLine = affectedFile.split('\n')[1]
                if secondLine.startswith("index") == 0: # or secondLine.endswith("100644") == 0:
                    if debugMode:
                        print("\t[+]", codePath, "(invalid metadata)")
                else:
                    if debugMode:
                        print("\t[+]", codePath)
                    indexHashOld = secondLine.split(' ')[1].split('..')[0]
                    indexHashNew = secondLine.split(' ')[1].split('..')[1]

                    chunksList = re.split(pat_chunk, affectedFile)[1:]
                    chunksCnt += len(chunksList)

                    oldFileName = "{0}_{1}_{2}_old".format(diffFileName.split('.di')[0], indexHashOld, affectedFileName)
                    newFileName = "{0}_{1}_{2}_new".format(diffFileName.split('.di')[0], indexHashNew, affectedFileName)

                    oldFileToParse = originalDir + "/tmp/" + str("{0}_old_{1}_{2}".format(diffFileName.split('.di')[0], indexHashOld, affectedFileName))
                    newFileToParse = originalDir + "/tmp/" + str("{0}_new_{1}_{2}".format(diffFileName.split('.di')[0], indexHashOld, affectedFileName))
                    shutil.copy(os.path.join(diffDir, repoName, oldFileName), oldFileToParse)
                    shutil.copy(os.path.join(diffDir, repoName, oldFileName), newFileToParse)
                    if codePath.endswith(".c") or codePath.endswith(".cpp") or codePath.endswith(".cc") or codePath.endswith(".c++") or codePath.endswith(".cxx"):
                        oldFunctionInstanceList = parseutility.parse_c_shallow(os.path.join(diffDir, repoName, oldFileToParse), "")
                        newFunctionInstanceList = parseutility.parse_c_shallow(os.path.join(diffDir, repoName, newFileToParse), "")
                        language = "c"
                    elif codePath.endswith(".java"):
                        oldFunctionInstanceList = parseutility.parse_java_shallow(os.path.join(diffDir, repoName, oldFileToParse))
                        newFunctionInstanceList = parseutility.parse_java_shallow(os.path.join(diffDir, repoName, newFileToParse))
                        language = "java"
                    elif codePath.endswith(".py"):
                        oldFunctionInstanceList = parseutility.parse_python_shallow(os.path.join(diffDir, repoName, oldFileToParse))
                        newFunctionInstanceList = parseutility.parse_python_shallow(os.path.join(diffDir, repoName, newFileToParse))
                        language = "python"
                    elif codePath.endswith(".go"):
                        oldFunctionInstanceList = parseutility.parse_go_shallow(os.path.join(diffDir, repoName, oldFileToParse))
                        newFunctionInstanceList = parseutility.parse_go_shallow(os.path.join(diffDir, repoName, newFileToParse))
                        language = "go"
                    elif codePath.endswith(".js"):
                        oldFunctionInstanceList = parseutility.parse_js_shallow(os.path.join(diffDir, repoName, oldFileToParse))
                        newFunctionInstanceList = parseutility.parse_js_shallow(os.path.join(diffDir, repoName, newFileToParse))
                        language = "js"
                    finalOldFunctionList = []

                    numChunks = len(chunksList)
                    for ci, chunk in enumerate(chunksList):
                        if debugMode:
                            print("\t\tChunk # " + str(ci + 1) + "/" + str(numChunks)),

                        chunkSplitted = chunk.split('\n')
                        chunkFirstLine = chunkSplitted[0]
                        chunkLines = chunkSplitted[1:]

                        if debugMode:
                            print(chunkFirstLine)
                        lineNums = pat_linenum.search(chunkFirstLine)
                        oldLines = lineNums.group(1).split(',')
                        newLines = lineNums.group(2).split(',')

                        offset = int(oldLines[0])
                        pmList = []
                        lnList = []
                        for chunkLine in chunkSplitted[1:]:
                            if len(chunkLine) != 0:
                                pmList.append(chunkLine[0])

                        for i, pm in enumerate(pmList):
                            if pm == ' ' or pm == '-':
                                lnList.append(offset + i)
                            elif pm == '+':
                                lnList.append(offset + i - 1)
                                offset -= 1

                        hitOldFunctionList = []

                        for f in oldFunctionInstanceList:
                            for num in range(f.lines[0], f.lines[1] + 1):
                                if num in lnList:
                                    hitOldFunctionList.append(f)
                                    break
                        for f in hitOldFunctionList:
                            for num in range(f.lines[0], f.lines[1] + 1):
                                print("num ", num);
                                try:
                                    listIndex = lnList.index(num)
                                except ValueError:
                                    pass
                                else:
                                    if lnList.count(num) > 1:
                                        listIndex += 1

                                    if pmList[listIndex] == '+' or pmList[listIndex] == '-':
                                        flag = 0
                                        for commentKeyword in ["/*","*/","//","*"]:
                                            if chunkLines[listIndex][1:].lstrip().startswith(commentKeyword):
                                                flag = 1
                                                break
                                        if flag:
                                            pass
                                        else:
                                            finalOldFunctionList.append(f)
                                            break
                                    else:
                                        pass

                    finalOldFunctionList = list(set(finalOldFunctionList))  # sometimes list has dups
                    finalNewFunctionList = []

                    for fold in finalOldFunctionList:
                        flag = 0
                        for fnew in newFunctionInstanceList:
                            if fold.name == fnew.name:
                                finalNewFunctionList.append(fnew)
                                flag = 1
                                break
                        if not flag:
                            finalNewFunctionList.append(dummyFunction)

                    if debugMode:
                        print("\t\t\t", len(finalNewFunctionList), "functions found.")

                    # query for cvss , cwe / cvss type change to make 5 => 5.0
                    splitName = diffFileName.split('.diff')[0].split('_')
#                    cveData = query.get_data_from_cve(splitName[0])
#                    newName = "_".join([splitName[0],str(float(cveData[0])), cveData[1], splitName[1]])
#                    vulFileNameBase = newName + '_' + affectedFileName

                    for index, f in enumerate(finalOldFunctionList):
                        os.chdir(originalDir)
                        oldFuncInstance = finalOldFunctionList[index]

                        fp = open(oldFuncInstance.parentFile, 'r', encoding="UTF8", errors='replace')
                        srcFileRaw = fp.readlines()
                        fp.close()
                        finalOldFunction = ''.join(srcFileRaw[oldFuncInstance.lines[0]-1:oldFuncInstance.lines[1]])
                        finalOldFuncId = str(oldFuncInstance.funcId)
                        newFuncInstance = finalNewFunctionList[index]

                        if newFuncInstance.name is None:
                            finalNewFunction = ""
                        else:
                            fp = open(newFuncInstance.parentFile, 'r', encoding="UTF8", errors='replace')
                            srcFileRaw = fp.readlines()
                            fp.close()
                            finalNewFunction = ''.join(srcFileRaw[newFuncInstance.lines[0]-1:newFuncInstance.lines[1]])

                        if language != "python":
                            finalOldBody = finalOldFunction[finalOldFunction.find('{')+1:finalOldFunction.rfind('}')]
                            finalNewBody = finalNewFunction[finalNewFunction.find('{')+1:finalNewFunction.rfind('}')]
                        else:
                            finalOldBody = finalOldFunction[finalOldFunction.find(':')+1:]
                            finalNewBody = finalNewFunction[finalNewFunction.find(':')+1:]

                        tmpold = parseutility.normalize(parseutility.removeComment(finalOldBody, language))
                        tmpnew = parseutility.normalize(parseutility.removeComment(finalNewBody, language))

                        with ctr.functionCntLock:
                            ctr.functionCnt.value += 1
                        os.chdir(os.path.join(originalDir, "vul", repoName))
                        vulOldFileName = finalOldFuncId + affectedFileName + '_' + finalOldFuncId + "_OLD.vul"
                        vulNewFileName = finalOldFuncId + affectedFileName + '_' + finalOldFuncId + "_NEW.vul"
#                        vulOldFileName = finalOldFuncId + affectedFileName + '_' + finalOldFuncId + "_OLD.vul"
#                        vulNewFileName = finalOldFuncId + affectedFileName + '_' + finalOldFuncId + "_NEW.vul"

                        with open(vulOldFileName, 'w', encoding='UTF8') as fp:
                            fp.write(finalOldFunction)
                        with open(vulNewFileName, 'w', encoding='UTF8') as fp:
                            if finalNewFunctionList[index].name is not None:
                                fp.write(finalNewFunction)
                            else:
                                fp.write("")

#                            diffCommand = "\"{0}\" -u {1} {2} >> {3}_{4}.patch".format("diff",
#                                                                                       vulOldFileName,
#                                                                                       vulNewFileName,
#                                                                                       vulFileNameBase,
#                                                                                       finalOldFuncId)
                            # os.system(diffCommand + ">nul 2>nul")
#                            os.system(diffCommand + " 2>nul")


def main():
    global total
    global repoName

    '''repos = ['1']
    repoTotal = len(repos)
    count = 1'''
    repos = os.listdir(diffDir)

    repoTotal = len(repos)
    count = 1

    for repoName in repos:
        try:
            os.makedirs(os.path.join(originalDir, 'vul', repoName))
        except OSError as e:
            pass

        ctr = Counter()
        ctr.functionCnt.value = 0
        ctr.diffFileCnt.value = 0
        diffList = []
        for f in os.listdir(os.path.join(diffDir, repoName)):
            if f.endswith(".diff"):
                diffList.append(f)
        total = len(diffList)
        if debugMode or "Windows" in platform.platform():

            for diffFile in diffList:
                source_from_cvepatch(ctr, diffFile)
        else:
            pool = mp.Pool()
            parallel_partial = partial(source_from_cvepatch, ctr)
            pool.map(parallel_partial, diffList)
            pool.close()
            pool.join()
        wildcard_temp = os.path.join(originalDir, "tmp", repoName + "_*")
        for f in glob.glob(wildcard_temp):
            os.remove(f)

        print("")
        print("Done getting vulnerable functions from {0} ({1}/{2})".format(repoName, count, repoTotal))
        count += 1;

        print("Reconstructed", ctr.functionCnt.value, "vulnerable functions from", ctr.diffFileCnt.value, "patches.")
        print("Elapsed: %.2f sec" % (time.time() - t1))
        shutil.rmtree(os.path.join(originalDir, 'tmp'))
        os.makedirs(os.path.join(originalDir, 'tmp'))

if __name__ == "__main__":
    mp.freeze_support()
    class Counter:
        diffFileCnt = mp.Value('i', 0)
        diffFileCntLock = mp.Manager().Lock()
        functionCnt = mp.Value('i', 0)
        functionCntLock = mp.Manager().Lock()
    init()
    main()
